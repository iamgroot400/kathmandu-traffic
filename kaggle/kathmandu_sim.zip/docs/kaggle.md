# Running simulations on Kaggle

Kaggle's free CPU notebooks give about 30 GB RAM and 4 cores, with a 12-hour session
limit. One simulation needs about 4.5 GB, so about 4 can run side by side there
(`--jobs 4`), against 1 on the home PC.

1. Zip the project without the environments and big files:
   `scripts/`, `checks/`, `data/` (59 MB), `results/`, `requirements.txt`.
   Leave out `.venv/`, `.venv-vision/`, `paper/`, `demo/`, videos.
2. Kaggle > Create > New Notebook. Settings: **Accelerator: None** (a GPU does not help,
   UXsim is CPU-only), **Internet: On** (phone verification needed once).
3. Add Data > Upload > the zip, as a private dataset.
4. First cell:
   ```
   !cp -r /kaggle/input/<dataset-name>/* /kaggle/working/ && cd /kaggle/working && pip install -q -r requirements.txt
   ```
5. Run a script, e.g.
   ```
   !cd /kaggle/working && python -u scripts/compare_followups.py --seeds 15 --jobs 4
   ```
   The queues write `results/*.partial.csv` after every run, so a session that hits the
   12-hour limit loses at most the runs in progress. Download `results/` before the
   session ends (Output tab, or "Save Version" to keep the files).
6. Copy the downloaded `results/*.partial.csv` back into the project here; the scripts
   resume from them.

Keep `--jobs` at or below RAM / 5 GB, or runs crash with out-of-memory errors.
